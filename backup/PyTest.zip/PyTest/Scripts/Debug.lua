Debug = { }

function Debug.PrintMouseStatus(mouseStatus)
	print(mouseStatus.x, mouseStatus.y, mouseStatus.left, mouseStatus.middle, mouseStatus.right)
end