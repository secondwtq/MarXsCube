OBJECTS.TESTANIM = BASES.BaseAnim:newObject({
	image = "TESTANIM_TEX",
	loop_count = 1,
	offset = { x = 10, y = -38 },
	scale = { x = 100, y = 100 },
})

OBJECTS.TESTDDS = BASES.BaseAnim:newObject({
	image = "TESTDDS_TEX",
	loop_count = 1,
})

OBJECTS.TESTANIMNEXT = BASES.BaseAnim:newObject({
	image = "TESTANIM_TEX_FULL",
	loop_count = 1,
})