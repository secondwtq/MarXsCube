OBJECTS.TECHTECHNO = BASES.BaseTechno:newObject({
	image = "TESTANIM_TEX",

	physics = {
		enabled = false
	}
})