This package is part of Project MarKsCube (Prototype).

Copyright 2014 SecondDatke & moderKENOSIS.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT 
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR 
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE 
OR OTHER DEALINGS IN THE SOFTWARE.

Other Credits:

----------

SFML (Simple and Fast Multimedia Library) - Copyright (c) Laurent Gomila: http://www.sfml-dev.org/

----------

Bullet Collision Detection and Physics Library: http://bulletphysics.org
Copyright (c) 2012 Advanced Micro Devices, Inc.

----------

The Lua Programming Language: http://www.lua.org

Copyright (c) 1994�C2014 Lua.org, PUC-Rio. 

----------

LuaBridge: https://github.com/vinniefalco/LuaBridge

Copyright 2012, Vinnie Falco (<vinnie.falco@gmail.com>)
Copyright 2008, Nigel Atkinson
Copyright 2007, Nathan Reed

----------

The Python Programming Language: https://www.python.org

Copyright (c) 2001-2013 Python Software Foundation; All Rights Reserved.