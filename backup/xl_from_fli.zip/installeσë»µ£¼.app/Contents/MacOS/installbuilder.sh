#!/bin/sh

# filepath=$(cd "$(dirname "$0")"; pwd)
# echo $filepath

# "`dirname \"${0}\"`/launcher-osx" "$@"

cd "`dirname \"${0}\"`"
cd "../Resources"

"./MarXsCube"