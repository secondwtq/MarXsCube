#!/bin/sh

"`dirname \"${0}\"`/launcher-osx" "$@"