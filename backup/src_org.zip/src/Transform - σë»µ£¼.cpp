#include "Transform.h"
#include "Common.h"
#include "Python/Python.h"
#include "Session.h"

#include <armadillo>
using namespace arma;

const int WIDTH_ = 1;
const int HEIGHT_ = WIDTH_ * 0.75;

vec up_vector = {0, 0, 1};
vec look_at = {0, 0, 0};

void testLapack() {
	auto _cam_pos = Session::GetInstance().CameraLocation;
	vec cam_pos = { (double)(_cam_pos.x), (double)(_cam_pos.y), (double)(_cam_pos.z) };
	vec za = normalise(cam_pos - look_at);
	// auto x = LaGenMatDouble::zeros(4, 4);
}

void UpdateVm(int ox, int oy) {
	testLapack();
	static auto pName = PyString_FromString("LinalG");
	static auto pModule = PyImport_Import(pName);
	static auto pDict = PyModule_GetDict(pModule);
	static auto pFunc = PyDict_GetItemString(pDict, "updateVm");
	auto pArgs = Py_BuildValue("dd", ox / 16.0, oy / 16.0);
	PyEval_CallObject(pFunc, pArgs);
	Py_DECREF(pArgs);
}

sf::Vector2f GetViewPos_Py(const sf::Vector3f &coord) {
static auto pName = PyString_FromString("LinalG");
static auto pModule = PyImport_Import(pName);
static auto pDict = PyModule_GetDict(pModule);

	static auto pFunc = PyDict_GetItemString(pDict, "getViewPos");

	auto pArgs = Py_BuildValue("fff", coord.x / (float)DIVS, coord.y / (float)DIVS, coord.z / (float)DIVS);
	PyObject *pRet = PyEval_CallObject(pFunc, pArgs);
	float ret[2];
	if (pRet && PyArg_ParseTuple(pRet, "ff", &(ret[0]), &(ret[1]))) {
		Py_DECREF(pArgs);
		Py_DECREF(pRet);
		return sf::Vector2f(ret[0] * WIDTH_, ret[1] * WIDTH_);
	}
	return sf::Vector2f(0, 0);
}

sf::Vector2i GetViewPos_Py(const sf::Vector3i &coord) {
static auto pName = PyString_FromString("LinalG");
static auto pModule = PyImport_Import(pName);
static auto pDict = PyModule_GetDict(pModule);
	static auto pFunc = PyDict_GetItemString(pDict, "getViewPos");

	auto pArgs = Py_BuildValue("fff", coord.x / (float)DIVS, coord.y / (float)DIVS, coord.z / (float)DIVS);
	PyObject *pRet = PyEval_CallObject(pFunc, pArgs);
	float ret[2];
	if (pRet && PyArg_ParseTuple(pRet, "ff", &(ret[0]), &(ret[1]))) {
		Py_DECREF(pArgs);
		Py_DECREF(pRet);
		return sf::Vector2i(ret[0] * WIDTH_, ret[1] * WIDTH_);
	}
	return sf::Vector2i(0, 0);
}

// sf::Vector2i GetViewPos_Py(const CoordStruct &coord) {
// static auto pName = PyString_FromString("LinalG");
// static auto pModule = PyImport_Import(pName);
// static auto pDict = PyModule_GetDict(pModule);
// 	static auto pFunc = PyDict_GetItemString(pDict, "getViewPos");

// 	auto pArgs = Py_BuildValue("fff", -coord.x / (float)DIVS, -coord.y / (float)DIVS, -coord.z / (float)DIVS);
// 	PyObject *pRet = PyEval_CallObject(pFunc, pArgs);
// 	float ret[2];
// 	if (pRet && PyArg_ParseTuple(pRet, "ff", &(ret[0]), &(ret[1]))) {
// 		Py_DECREF(pArgs);
// 		Py_DECREF(pRet);
// 		return sf::Vector2i(ret[0], ret[1]);
// 	}
// 	return sf::Vector2i(0, 0);
// }

#define MULT 41.5

sf::Vector2f GetViewPos_Py(const CoordStruct &coord) {
static auto pName = PyString_FromString("LinalG");
static auto pModule = PyImport_Import(pName);
static auto pDict = PyModule_GetDict(pModule);
static auto pFunc = PyDict_GetItemString(pDict, "getViewPos");
// static auto pTupleArg = PyTuple_New(4);
// PyTuple_SetItem(pTupleArg, 0, PyFloat_FromDouble(-coord.x / (double)DIVS));
// PyTuple_SetItem(pTupleArg, 1, PyFloat_FromDouble(-coord.y / (double)DIVS));
// PyTuple_SetItem(pTupleArg, 2, PyFloat_FromDouble(-coord.z / (double)DIVS));
// PyTuple_SetItem(pTupleArg, 3, PyFloat_FromDouble(1));
	auto pArgs = Py_BuildValue("fff", -coord.x / (float)DIVS, -coord.y / (float)DIVS, -coord.z / (float)DIVS);

	float ret[2];
	PyObject *pRet = PyEval_CallObject(pFunc, pArgs); //	PyObject_CallFunctionObjArgs(pFunc, pTupleArg, NULL);
	
	if (pRet && PyArg_ParseTuple(pRet, "ff", &(ret[0]), &(ret[1]))) {
		Py_DECREF(pRet);
		Py_DECREF(pArgs);
		return sf::Vector2f(ret[0]*MULT, ret[1]*MULT);
	}
	return sf::Vector2f(0, 0);
}

sf::Vector2f x(0, 0);

void GetViewPos_Py_Opted(PyObject *xtuple) {
static auto pName = PyString_FromString("LinalG");
static auto pModule = PyImport_Import(pName);
static auto pDict = PyModule_GetDict(pModule);
static auto pFunc = PyDict_GetItemString(pDict, "getViewPos_");
PyObject *pRet = PyObject_CallFunctionObjArgs(pFunc, xtuple, NULL);
	PyArg_ParseTuple(pRet, "o", &pRet);
	x.x = PyFloat_AsDouble(PyList_GetItem(pRet, 0)) * MULT;
	x.y = PyFloat_AsDouble(PyList_GetItem(pRet, 1)) * MULT;
	Py_DECREF(pRet);
}

CoordStruct GetWorldPos_Py(const CubePoint &pt) {
static auto pName = PyString_FromString("LinalG");
static auto pModule = PyImport_Import(pName);
static auto pDict = PyModule_GetDict(pModule);
static auto pFunc = PyDict_GetItemString(pDict, "getViewPos_inv");
	auto pArgs = Py_BuildValue("ff", pt.x / (float)MULT, pt.y / (float)MULT);
	float ret[2];
	PyObject *pRet = PyEval_CallObject(pFunc, pArgs);
	if (pRet && PyArg_ParseTuple(pRet, "ff", &(ret[0]), &(ret[1]))) {
		Py_DECREF(pRet);
		Py_DECREF(pArgs);
		return CoordStruct(-ret[0]*64.0, -ret[1]*64.0, 0);
	}
	return CoordStruct(0, 0, 0);
}

template <typename T>
void printVector(T src) { }

template<> void printVector(Vector2i src) {
	printf("%d %d\n", src.x, src.y);
}

template<> void printVector(Vector2f src) {
	printf("%.3f %.3f\n", src.x, src.y);
}

template<> void printVector(Vector3i src) {
	printf("%d %d %d\n", src.x, src.y, src.z);
}

template <>
void printVector(const Vector2f& src) {
	printf("%.3f %.3f\n", src.x, src.y);
}